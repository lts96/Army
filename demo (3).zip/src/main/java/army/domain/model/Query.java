package army.domain.model;

public class Query 
{
	private String user_id; 
	private String last_update; 
	public Query() {
		
	}
	public Query(String id , String time)
	{
		this.setUser_id(id); 
		this.setLast_update(time);
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getLast_update() {
		return last_update;
	}
	public void setLast_update(String last_update) {
		this.last_update = last_update;
	}
	
}
