package army.domain.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "log")
public class Log 
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer logId;
	private String userId; 
	private String occurTime; 
	private Integer groupPin; // 우저가 속한 그룹
	private int violation;    // 우저가 위반한 사항 체크용 
	
	
	
	
	public int getViolation() {
		return violation;
	}
	public void setViolation(int violation) {
		this.violation = violation;
	}
	public Integer getLogId() {
		return logId;
	}
	public void setLogId(Integer logId) {
		this.logId = logId;
	}
	
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getGroupPin() {
		return groupPin;
	}
	public void setGroupPin(Integer groupPin) {
		this.groupPin = groupPin;
	}
	
}
