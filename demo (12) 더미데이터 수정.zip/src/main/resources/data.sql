-- 영화 목록
INSERT INTO soldier (user_id, soldier_pw , soldier_name , soldier_class , last_time , soldier_phonenumber , soldier_imei , vacation ,group_pin, camera , enable , screen)
 VALUES ('dddddddd','awfeom123','이수', '병장','201905020000','01092946781', 'sn - 9000',1 , 123456 ,1,1,1);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('aaa1234','enviaeh41','이재용','일병','201905030000','01097458754',  'sn - 12300' ,1, 123456,0,0,0);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('dklwifma21231','iiii23124','안대용','이병','201911020000', '01078941231', 'sn - 3300',1, 123456,1,1,1);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('aeua123','87951@@','박병장','상병','201905020123', '01078841521', 'sn - 5550',1, 987654,0,0,0);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('aefweofm1','00291823','최폐급','상병','201105000000', '01055555555', 'sn - 2200',1, 987654,1,1,0);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('aefim00','8829910!!','우강제','일병','200205020000', '01099977787', 'sn - 1100',1, 987654,1,1,0);
INSERT INTO soldier (user_id,soldier_pw , soldier_name , soldier_class , last_time, soldier_phonenumber, soldier_imei, vacation,group_pin, camera , enable , screen) 
VALUES ('kkkkkk123','&**()@#$','송대장','병장','201205020000', '01033332222', 'sn - 900',1, 999999,1,1,1);




-- 사용자 (비밀번호: demo)
INSERT INTO usr (soldier_class , user_id, name, imei, role_name, phone_number, password ,group_name , last_update , online ,camera , enable , screen , group_pin)
VALUES ('대위','dlxotjs', '이태선', 'SN - 9010', 'ADMIN','01092946780' ,'1234' , '201정비중대' , '20191122120012',1,1,1,1,123456);
INSERT INTO usr (soldier_class ,user_id, name, imei, role_name, phone_number, password,group_name, last_update, online, camera , enable , screen  , group_pin)
VALUES ('소령','han', '한상훈', 'SN- 1111', 'ADMIN','01012341234', '5678', '207정비중대', '20181122120012',1,0,0,1,987654);
INSERT INTO usr (soldier_class ,user_id, name, imei, role_name, phone_number, password,group_name, last_update, online, camera , enable , screen, group_pin)
VALUES ('중사','chan', '정희찬', 'SN - 7774', 'ADMIN','01084751621', '0000', '101정비중대', '20171122120012',1,0,1,1,999999);




INSERT INTO soldier_group (group_id,soldier_id,group_name , group_time) VALUES (123456,1,'201정비중대' , '201801010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (123456,2,'201정비중대', '201701010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (123456,3,'201정비중대', '201601010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (987654,4,'101정비중대', '201901010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (987654,5,'101정비중대', '201501010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (987654,6,'101정비중대', '201401010122');
INSERT INTO soldier_group (group_id,soldier_id,group_name, group_time) VALUES (999999,7,'207정비중대', '201301010122');