package army.domain.service.soldier;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import army.domain.model.Log;
import army.domain.model.SoldierGroup;
import army.domain.repository.soldier.LogRepository;

@Service 
@Transactional
public class LogService {
	@Autowired
	LogRepository logRepository;
	
	@Transactional
	public List<Log> findAllLog(){
		return logRepository.findAll();
	}
	
	@Transactional
	public void saveLog(Log log) {
		logRepository.saveAndFlush(log);
	}
	@Transactional
	public List<Log> findLog(String userId){
		List<Log> allLog = logRepository.findAll();
		List<Log> userLog = new ArrayList<Log>();
		for(int i=0;i<allLog.size();i++)
		{
			if(allLog.get(i).getUserId().equals(userId))
			{
				userLog.add(allLog.get(i));
			}
		}
		return userLog;
	}
	
}
