package army.domain.model;

public class OutputForm {
	private String result;
	private int pin;
	public OutputForm() {
		result = " ";
	}
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	} 
	

}
