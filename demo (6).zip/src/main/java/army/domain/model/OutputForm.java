package army.domain.model;

public class OutputForm {
	private String result;
	
	public OutputForm() {
		result = " ";
	}
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	} 
	

}
