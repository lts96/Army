package com.example.strongfriends.Application.Activity.Datas

data class Periodic_response(var user_id:String, var last_update:String, var isLastOption:Int, var camera:Int, var enable:Int, var screen:Int, var control_time:String)