package com.example.strongfriends.Application.Activity.Datas

data class Result (var result:String)
