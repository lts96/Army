package com.example.strongfriends.Application.Activity.Datas

data class login_body(var userId:String,var password:String)