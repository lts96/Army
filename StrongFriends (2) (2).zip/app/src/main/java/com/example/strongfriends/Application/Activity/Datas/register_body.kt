package com.example.strongfriends.Application.Activity.Datas

data class register_body(var userId:String, var password:String,var imei:String,var phoneNumber:String,var groupName:String, var roleName:String, var name:String)

