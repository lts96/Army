package com.example.strongfriends.Application.Activity.Datas

data class Periodic_body(var user_id:String,var last_update:String)