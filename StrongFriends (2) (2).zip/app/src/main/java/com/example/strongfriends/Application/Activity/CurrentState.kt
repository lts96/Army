package com.example.strongfriends.Application.Activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.strongfriends.R

class CurrentState : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_current_state)
        init()
    }
    fun init(){

    }
}
