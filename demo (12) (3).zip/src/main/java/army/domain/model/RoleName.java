package army.domain.model;

public enum RoleName {
    ADMIN, USER
}
