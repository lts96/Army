package army.domain.service.soldier;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import army.domain.model.Soldier;
import army.domain.repository.soldier.SoldierRepository;

import army.domain.repository.soldier.GroupRepository;
import army.domain.model.SoldierGroup;
import army.domain.model.User;
import army.domain.model.GroupId;

@Service
@Transactional
public class SoldierService {
	
    @Autowired
    GroupRepository groupRepository;
    
    @Autowired
    SoldierRepository soldierRepository;
    
    @Transactional
    public SoldierGroup findByGroupId(int groupId) {
        return groupRepository.findByGroupId(groupId);
    }
    
    @Transactional
    public List<SoldierGroup> findAllGroups(Integer groupId) {
        return groupRepository
                .findByGroupId_groupIdOrderByGroupId_soldierIdAsc(groupId);
    }
    
    @Transactional
	public List<SoldierGroup> findAllGroups() {
		return groupRepository.findAll();
	}
	
    @Transactional
	public List<Soldier> findAllSoldiers()
	{
		return soldierRepository.findAll();	
	}
    
    @Transactional
	public Soldier findSoldier(int id)
	{
		return soldierRepository.findOne(id);
	}
    @Transactional public Soldier findSoldier(String id)  //userId 로 해당하는 soldier 찾기 
    {
    	List<Soldier> list = soldierRepository.findAll();
    	Soldier soldier = null;;
    	for(int i=0;i<list.size();i++)
    	{
    		if(list.get(i).getUserId().equals(id))
    		{
    			soldier = list.get(i);
    			return soldier;
    		}
    	}
    	return soldier;
    }
    
    @Transactional
	public void updateSoldier(Soldier soldier)
	{
		soldierRepository.saveAndFlush(soldier);
	}
    @Transactional
	public void createSoldier(Soldier soldier)
	{
		soldierRepository.saveAndFlush(soldier);
	}
    @Transactional
    public Soldier createSoldier(User user)
    {
    	Soldier soldier = new Soldier();  
    	soldier.setUserId(user.getUserId());
    	soldier.setGroupPin(user.getGroupPin());
    	soldier.setCamera(user.getCamera());
    	soldier.setEnable(user.getEnable());
    	soldier.setLastTime(user.getLastUpdate());
    	soldier.setScreen(user.getScreen());
    	soldier.setSoldierClass(user.getSoldierClass());
    	soldier.setSoldierImei(user.getIMEI());
    	soldier.setSoldierName(user.getName());
    	soldier.setSoldierPhonenumber(user.getPhoneNumber());
    	soldier.setSoldierPw(user.getPassword());
    	soldier.setVacation(1);
    	
    	soldier.setOnline(user.getOnline());
    	soldierRepository.saveAndFlush(soldier);
    	return soldier;
    }
    
    @Transactional
	public void deleteSoldier(Soldier entity) {
		soldierRepository.delete(entity);
	}
	@Transactional
	public SoldierGroup createGroup(Soldier soldier , int Idset, String groupName , String groupTime) {
		SoldierGroup newGroup = new SoldierGroup();
		GroupId groupId = new GroupId();
		groupId.setGroupId(Idset);
		groupId.setSoldierId(soldier.getSoldierId());
		newGroup.setGroupId(groupId);
		newGroup.setGroupName(groupName);
		newGroup.setGroupTime(groupTime);
		
		soldier.setGroupPin(Idset);
		
		createSoldier(soldier);
		newGroup.setSoldier(soldier);
		return groupRepository.saveAndFlush(newGroup);
	}
	@Transactional
	public SoldierGroup findGroup(int groupPin)
	{
		List<SoldierGroup> list = groupRepository.findAll();
		SoldierGroup group = null;
		for(int i=0;i<list.size();i++)
		{
			if(list.get(i).getGroupId().getGroupId() == groupPin)
				group = list.get(i);
		}
		return group;
	}
	@Transactional
	public void updateGroup(SoldierGroup entity)
	{
		groupRepository.saveAndFlush(entity);
	}
	
	
	@Transactional
	public void deleteGroup(GroupId id) {
		groupRepository.delete(id);
	}
	@Transactional
	public void deleteAllGroups() {
		groupRepository.deleteAll();
	}
}