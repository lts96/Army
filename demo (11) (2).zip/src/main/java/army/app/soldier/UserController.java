package army.app.soldier;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import army.domain.model.GroupId;
import army.domain.model.Log;
import army.domain.model.LoginForm;
import army.domain.model.OutputForm;
import army.domain.model.Query;
import army.domain.model.QueryInput;
import army.domain.model.SearchForm;
import army.domain.model.Soldier;
import army.domain.service.soldier.LogService;
import army.domain.service.soldier.SoldierService;
import army.domain.service.soldier.UserService;
import army.domain.model.SoldierGroup;
import army.domain.model.User;

//               ok 표시가 들어간 함수들은 기능이 잘 돌아가는 것들 , 구현 완료 표시라고 보면됩니다.
@CrossOrigin(origins = {"*","http://221.155.56.120:8080" })
//@CrossOrigin(origins = {"http://localhost:8100","http://localhost:8080" })
@RestController
public class UserController {
	
	
	public static final Object logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    SoldierService soldierService;
    
    @Autowired
    UserService userService;
    
    @Autowired
    LogService logService;
    
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}/{soldierId}", method = RequestMethod.GET) // 그룹 내 군인 정보 하나를 가져옴 ok
    public ResponseEntity<Soldier> findSoldiers(@PathVariable("groupId")int groupId , // 주의 사항 0부터 시작하기때문에  만약 2번 그룹에 3개가 있을경우 
    		@PathVariable("soldierId")int soldierId ,Model model){					  // main/2/0 main/2/1 main/2/2 이런식으로 접근해야함
    	
    	List<SoldierGroup> soldierGroup = soldierService.findAllGroups(groupId);
    	
    	
    	SoldierGroup group = soldierGroup.get(soldierId);
    	Soldier soldier = group.getSoldier();
    	
    	return new ResponseEntity<Soldier>(soldier, HttpStatus.OK);
    	
    }
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}/{soldierId}", method = RequestMethod.POST) // 그룹 내 군인 정보 하나를 추가함
    public ResponseEntity<Soldier> createSoldiers(@PathVariable("groupId")int groupId , 
    		@PathVariable("soldierId")int soldierId ,@RequestBody Soldier soldier){
    	
    	
    	List<SoldierGroup> soldierGroup = soldierService.findAllGroups(groupId);
    	
    	
    	SoldierGroup group = soldierGroup.get(soldierId);
    	group.setSoldier(soldier);
    	
    	return new ResponseEntity<Soldier>(soldier, HttpStatus.OK);
    }
    
    
    
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}/{soldierId}", method = RequestMethod.DELETE) // 그룹 내 군인 정보 하나를 지움 -> 사실상 그룹하나를 지우는 것 , soldier 객체는 그대로 남음
    public ResponseEntity<OutputForm> deleteSoldiers(@PathVariable("groupId")int groupId , 
    		@PathVariable("soldierId")int soldierId ,Model model) throws CloneNotSupportedException{
    	OutputForm result = new OutputForm();
    	List<SoldierGroup> soldierGroup = soldierService.findAllGroups(groupId);
    	//Soldier temp;
    	for(int i=0;i<soldierGroup.size();i++)
    	{
    		if(soldierGroup.get(i).getSoldier().getSoldierId().equals(soldierId))
    		{
    			User user = userService.findUser(soldierGroup.get(i).getSoldier().getUserId());
    			GroupId id = new GroupId(groupId,soldierId);
    			//temp = (Soldier) soldierGroup.get(i).getSoldier().clone();
    			//soldierService.createSoldier(temp);
    			soldierService.deleteGroup(id);
    			user.setGroupName("없음");
    			user.setGroupPin(-1);
    			userService.save(user);
    			soldierGroup.get(i).getSoldier().setGroupPin(-1);
    			soldierService.updateSoldier(soldierGroup.get(i).getSoldier());
    			result.setResult("delete_success ");
    			return new ResponseEntity<OutputForm>( result, HttpStatus.OK);
    		}
    	}
    	result.setResult("can't find it , try again");
    	return new ResponseEntity<OutputForm>( result, HttpStatus.OK);
    }
    
    
    /*
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}/{soldierId}", method = RequestMethod.PUT) // 그룹 내 군인 정보 하나를 갱신  밑의 createGroup에서 같이한다
    public void updateSoldiers(@PathVariable("groupId")int groupId , 
    		@PathVariable("soldierId")int soldierId ,@RequestBody Soldier soldier){
    	
    	//List<SoldierGroup> soldierGroup = soldierService.findAllGroups(groupId);
    	soldierService.updateSoldier( soldier);
    	
    }*/
    
    
    
    
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}", method = RequestMethod.GET) // 그룹 하나의 정보를 가져옴    ok
    public ResponseEntity<List<SoldierGroup>> findGroup(@PathVariable("groupId")int groupId ,Model model) {
    	
    	
    	List<SoldierGroup> soldierGroup = soldierService.findAllGroups(groupId);
    	
    	if (soldierGroup==null) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
    	return new ResponseEntity<List<SoldierGroup>>(soldierGroup, HttpStatus.OK);
    }
    
    //   그룹 하나 만들어주기, 유저는 이 group의 name (핀 번호)를 가지게 된다. 생성된 빈 그룹을 리턴 
    
	@ResponseBody
    @RequestMapping(value = "/main/userlist/{userId}/createGroup",method = RequestMethod.POST)  // 생성은 되는데 빈값 들어감 -> 수정 , 내가 전달한 soldier 값으로 들어감
    public ResponseEntity<?> createGroup(@PathVariable("userId")String userId ,@RequestBody Soldier soldier ) {
		User user =	userService.findUser(userId);
		
		// group의 pin은 이걸 소유한 user의 pin으로 한다.
    	SoldierGroup newGroup  = soldierService.createGroup(soldier,user.getGroupPin(),user.getGroupName(),"0"); // 초기 시간은 0으로 설정 
		if(newGroup != null)
			return new ResponseEntity<SoldierGroup>(newGroup, HttpStatus.OK);
		else 
			return new ResponseEntity<String>("creating empty group is fail", HttpStatus.OK);
    }
	
	
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}", method = RequestMethod.POST) // 그룹의 정보를 바꿈. (일단은 이름만 테스트) ok   
    public ResponseEntity<List<SoldierGroup>> updateGroup(@PathVariable("groupId")int groupId ,@RequestBody String name) {
    	
    	
    	List<SoldierGroup> soldierGroups = soldierService.findAllGroups(groupId);
    	for(int i=0;i<soldierGroups.size();i++)
    	{
    		soldierGroups.get(i).setGroupName(name);                                     // 그냥 "" 없이 원하는 이름 넣으면 됨.
    	}
    	
    	
    	return new ResponseEntity<List<SoldierGroup>>(soldierGroups, HttpStatus.OK);
    }
    @ResponseBody
    @RequestMapping(value = "/main/{groupId}", method = RequestMethod.DELETE) // 그룹을 통째로 지움. ok
    public ResponseEntity<?> deleteGroup(@PathVariable("groupId")int groupId ,Model model) {
    	
    	
    	List<SoldierGroup> soldierGroups = soldierService.findAllGroups(groupId);
    	for(int i=0;i<soldierGroups.size();i++)
    	{
    		//soldierService.deleteGroup(soldierGroups.get(i));
    	}
    	
    	return new ResponseEntity<>(HttpStatus.OK);
    }
    
    
    @ResponseBody
    @RequestMapping(value = "/main",method = RequestMethod.GET)  //전체 그룹 정보 전달 ok
    public List<SoldierGroup> listGroups( Model model) {
        List<SoldierGroup> soldierGroups = soldierService.findAllGroups();
        return soldierGroups;
    }
    @ResponseBody
    @RequestMapping(value = "/main/soldierlist",method = RequestMethod.GET)  //전체 그룹 정보 전달 ok
    public List<Soldier> listSoldiers( Model model) {
        List<Soldier> soldiers = soldierService.findAllSoldiers();
        return soldiers;
    } 
    @ResponseBody
    @RequestMapping(value = "/main",method = RequestMethod.DELETE)  //전체 그룹 정보 지우기 ok
    public ResponseEntity<?> deletelistGroups( Model model) {
        soldierService.deleteAllGroups();
        return new ResponseEntity<>(HttpStatus.OK);
    } 
   
    
    
    
    
    
    @ResponseBody
    @RequestMapping(value = "/main/sign_in",method = RequestMethod.POST)  // 회원 가입 부분
    public ResponseEntity<OutputForm> changeUserInfo(@RequestBody User user ) {    //user 객체 포맷이랑 정확하게 맞춰서 input 넣어야됨. 
    																			 
    	List<User> users = userService.findAllUser();
    	OutputForm result = new OutputForm();
    	String temp = "";
    	int sum = 0;
		int ran[] = new int[6];
		for(int i=0;i<6;i++) {                 // 중복없이 6자리수 생성 
			ran[i] = (int)(Math.random()*9)+1;
			
		    for(int j = 0; j < i; j ++){
		        if(ran[i] == ran[j]){
		            i--; 
		            break; 
		        }
		    }
		}
		for(int i=0;i<6; i++)
		{
			temp += Integer.toString(ran[i]);
		}
		sum = Integer.parseInt(temp);
    	
    	for(int i=0;i<users.size();i++) {
    		if(users.get(i).getUserId().equals(user.getUserId()))
    		{
    			result.setResult("REGISTER_FAIL_DUPID"); 
    			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
    		}
    	}
    	if(user.getRoleName().toString().equals("ADMIN"))
    		user.setGroupPin(sum);
    	else 
    	{
    		user.setGroupPin(-1);
    		// user와 대응하는 soldier 객체 필요?
    		soldierService.createSoldier(user);
    	}
    
    	userService.save(user);
    	result.setResult("REGISTER_OK"); 
		return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
    }
    
    
    @ResponseBody
    @RequestMapping(value = "/main/log_in",method = RequestMethod.POST)   																			
    public ResponseEntity<OutputForm> login(@RequestBody LoginForm login ) {   // outputform은 string 반환용  리턴에 pin 추가
    	List<User> users = userService.findAllUser();
    	OutputForm result = new OutputForm();
    	for(int i=0;i<users.size();i++)
    	{
    		if(users.get(i).getUserId().equals(login.getUserId()))
    		{
    			if(users.get(i).getPassword().equals(login.getPassword()))
        		{
    				result.setResult("LOGIN_SUCCESS"); 
    				result.setPin(users.get(i).getGroupPin());
        			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
        		}
    			else 
    			{
    				result.setResult("LOGIN_FAIL, WRONG PW"); 
    				return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
    			}
    		}
    	}
    	result.setResult("LOGIN_FAIL, WRONG ID"); 
    	return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
    }
    
    
    @ResponseBody
    @RequestMapping(value = "/main/userlist",method = RequestMethod.GET)  // 전체 유저 정보 확인용  ok 
    public ResponseEntity<List<User>> userList()
    {
    	List<User> users = userService.findAllUser();
    	return new ResponseEntity<List<User>>(users, HttpStatus.OK);
    }
    
	@ResponseBody
    @RequestMapping(value = "/main/userlist/userGroup",method = RequestMethod.POST)  // 유저가 관리하는 그룹 출력    이름을 기준으로 함  지금은 id랑 이름을 동기화 시켜서 가능한 것 ok
    public OutputForm userGroupList(@RequestBody SearchForm input)  // 지금은 유저당 그룹 하나를 관리한다고 생각하고 만듬 
    {																					  // 현재 관리하는 그룹 이름만 보냄   okok
    	List<SoldierGroup> soldierGroups = soldierService.findAllGroups();				  // put 이라서 user_id를 json으로 보내줘야됨
    	List<SoldierGroup> userGroup = new ArrayList<SoldierGroup>();
    	User user = userService.findUser(input.getUserId());
    	OutputForm result = new OutputForm();
    	for(int i=0;i<soldierGroups.size();i++)
    	{
    		if(user.getGroupName().equals(soldierGroups.get(i).getGroupName()))
    		{
    			userGroup.add(soldierGroups.get(i));
    			result.setResult(soldierGroups.get(i).getGroupName() + " " + Integer.toString(soldierGroups.get(i).getGroupId().getGroupId())); 
            	return result;
    		}
    	}
    	result.setResult("EMPTY");
    	return result;
    }

	@ResponseBody
    @RequestMapping(value = "/main/userlist/userSoldier",method = RequestMethod.POST)
	public ResponseEntity<List<Soldier>> userSoldierList(@RequestBody SearchForm input)
	{
		User user = userService.findUser(input.getUserId());
    	List<SoldierGroup> soldierGroups = soldierService.findAllGroups();
    	List<SoldierGroup> userGroup = new ArrayList<SoldierGroup>();
    	List<Soldier> soldiers = new ArrayList<Soldier>();
    	for(int i=0;i<soldierGroups.size();i++)
    	{
    		if(user.getGroupName().equals(soldierGroups.get(i).getGroupName())==true)
    		{
    			userGroup.add(soldierGroups.get(i));
    		}
    	}
    	for(int i=0;i<userGroup.size();i++)
    	{
    		soldiers.add(userGroup.get(i).getSoldier());
    	}
		return new ResponseEntity<List<Soldier>>(soldiers, HttpStatus.OK);
	}
	
	// 유저 id로 찾아서 해당 유저의 정보 통째로 리턴 
	
	@ResponseBody
    @RequestMapping(value = "/main/userlist/{userId}",method = RequestMethod.GET)
	public ResponseEntity<?> userInfomation (@PathVariable("userId")String userId)
	{
		OutputForm result = new OutputForm();
		User returnUser = userService.findUser(userId);
		if(returnUser == null)
		{
			result.setResult("can't find user , try again");
			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
		}
		else 
			return new ResponseEntity<User>(returnUser, HttpStatus.OK);
	}
	
	
	// 유저의 id와 방 핀번호 가지고 방에 입장하는 함수    돌아는 가는데 왠지 ??
	
	@ResponseBody
    @RequestMapping(value = "/main/gotoRoom/{userId}/{groupPin}",method = RequestMethod.GET)
	public ResponseEntity<?> gotoRoom (@PathVariable("userId")String userId ,@PathVariable("groupPin")Integer groupPin)
	{
		User user = userService.findUser(userId);
		OutputForm result = new OutputForm();
		if(user == null)
		{
			result.setResult("can't find user , try again");
			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
		}
		if(user.getRoleName().toString().equals("ADMIN"))     // 관리자가 들어갈때 방이 비었으면 하나 만들고 아니면 그냥 넘어가기
		{
			SoldierGroup group = soldierService.findGroup(user.getGroupPin());  
			if(group!=null)
			{
				result.setResult("group already exists.");
			}
			else 
			{
				Soldier empty = new Soldier();
				empty.setGroupPin(groupPin);
				createGroup(userId, empty);
				result.setResult("ADMIN create new Group");
			}
			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
		}
		
		List<SoldierGroup> soldierGroups = soldierService.findAllGroups();
    	for(int i=0;i<soldierGroups.size();i++) 
    	{
    		if(soldierGroups.get(i).getGroupId().getGroupId().equals(groupPin))     // 입력으로 들어온 pin과 같은 그룹을 찾았을때 
    		{
    			result.setResult("find and enter group");   // user data -> soldier 로 옮기고 soldier를 그룹과 연결해서 생성 (상속했어야 하는데 늦음)
    			result.setPin(groupPin);
    			user.setGroupPin(groupPin); 
    			user.setGroupName(soldierGroups.get(i).getGroupName());
    			
    			// 이미 user가 회원가입할때 대응되는 soldier 정보가 생성이 되므로 또 만들면 중복된다. 
    			// 찾아보고 없을 경우에만 생성하도록 
    			Soldier soldier = soldierService.findSoldier(user.getUserId());
    			if(soldier == null)
    				soldier = soldierService.createSoldier(user);   
    			createGroup(user.getUserId(), soldier);
    			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
    		}
    	}
    	// 만약 해당하는 그룹이 없을때   -> 유저 입장에서 그룹을 만들수는 없음.
    	
    	result.setResult("can't find group , try again");
		return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
	}
	
	// 위반사항 발생시 위반한 사람 정보 받아서 기록하는 함수   리턴 필요없음
	@ResponseBody
    @RequestMapping(value = "/main/updateLog",method = RequestMethod.POST)
	public int updateViolation (@RequestBody Log log){
		//OutputForm result = new OutputForm();
		logService.saveLog(log);
		if(logService.findLog(log.getUserId())!=null)
			return 1; 
		else 
			return 0;
	}
	
	// 해당 사용자와 관련된 로그 리턴해주는 함수 
	@ResponseBody
    @RequestMapping(value = "/main/loglist/{userId}",method = RequestMethod.GET)
	public ResponseEntity<?> getViolationList (@PathVariable("userId")String userId){
		OutputForm result = new OutputForm();
		List<Log> userlog = logService.findLog(userId);
		if(userlog == null)
		{
			result.setResult("can't find log");
			return new ResponseEntity<OutputForm>(result, HttpStatus.OK); 
		}
		return new ResponseEntity<List<Log>>(userlog, HttpStatus.OK); 
	
	}
	
	// 이건 쿼리 처리하는 함수 
	
	@ResponseBody
    @RequestMapping(value = "/main/userlist/userQuery",method = RequestMethod.POST)    // -> 이거 만드는 중이었음 자세한건 txt 요구사항 보고 만들기 
	public ResponseEntity<Query> userManagement(@RequestBody QueryInput queryInput)
	{
		User user = userService.findUser(queryInput.getUser_id());
		Query query = new Query();
		if(user.getRoleName().equals("ADMIN"))                           // 관리자일 경우 제한받지 않으므로 그냥 빠져나감
		{
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
    	long userTime = Long.parseLong(user.getLastUpdate());    // 현재 db 에 있는 유저의 시간 
    	long queryTime = Long.parseLong(queryInput.getLast_update());  // 입력으로 들어온 시간 
    	System.out.println("user Time  : "+ userTime);
    	System.out.println("query Time  : "+ queryTime);
    	if( queryTime > userTime )
    	{
    		user.setLastUpdate(queryInput.getLast_update());
    		query.setUser_id(user.getUserId());
    		query.setLast_update(user.getLastUpdate());
    		query.setControl_time(user.getLastUpdate()+queryInput.getLast_update());
    		query.setIsLastOption(1);
    		
    		System.out.println("query > user");
    	}
    	else 
    	{
    		query.setUser_id(user.getUserId());
    		query.setLast_update(user.getLastUpdate());
    		query.setIsLastOption(0);
    		query.setControl_time(queryInput.getLast_update()+user.getLastUpdate());
    		query.setLast_update(user.getLastUpdate());
    		query.setCamera(user.getCamera());
    		query.setEnable(user.getEnable());
    		query.setScreen(user.getScreen());
    		System.out.println("query <= user");
    	}
    	
    	
		return new ResponseEntity<Query>(query, HttpStatus.OK);
	}
	// soldier의 vacation 변수를 바꾸는 함수     리턴값은  오류 메세지를 string형태로 리턴 
	
		@ResponseBody
		@RequestMapping(value = "/main/vacation/{userId}/{soldierId}",method = RequestMethod.POST)
		public ResponseEntity<OutputForm> setVacation (@PathVariable("userId")String userId ,@PathVariable("soldierId")int soldierId ){
			User user = userService.findUser(userId);
			OutputForm result = new OutputForm();
			if(user == null)
			{
				result.setResult("can't find user"); 
				return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
			}
	    	List<SoldierGroup> soldierGroups = soldierService.findAllGroups();
	    	List<SoldierGroup> userGroup = new ArrayList<SoldierGroup>();
	    	List<Soldier> soldiers = new ArrayList<Soldier>();
	    	for(int i=0;i<soldierGroups.size();i++)
	    	{
	    		if(user.getGroupName().equals(soldierGroups.get(i).getGroupName())==true)
	    		{
	    			userGroup.add(soldierGroups.get(i));
	    		}
	    	}
	    	for(int i=0;i<userGroup.size();i++)
	    	{
	    		soldiers.add(userGroup.get(i).getSoldier());
	    		if(soldiers.get(i).getSoldierId()==soldierId)
	    		{
	    			soldiers.get(i).setVacation(-1);
	    			result.setResult("find soldier and change variable :  "+ soldiers.get(i).getVacation()); 
	    			soldierService.updateSoldier(soldiers.get(i));
	    			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
	    		}
	    	}
	    	result.setResult("can't find soldier"); 
			return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
		}
	@ResponseBody
	@RequestMapping(value = "/main/setTime/{groupId}",method = RequestMethod.POST)
	public ResponseEntity<?> setTime(){
		return 0;
		
	}
		
		
	// broadcast 기능을 하는 함수    그룹 내 사용자들 전체에게 메세지 전달?
	
	public ResponseEntity<OutputForm> broadcast(){
		
		OutputForm result = new OutputForm();
		
		
		return new ResponseEntity<OutputForm>(result, HttpStatus.OK);
	}
}