package army.domain.model;

import java.io.Serializable;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
public class Soldier implements Serializable , Cloneable{   // 원래 user를 상속하는 관계로 만들려고 했으나 예상치 못한 오류 터져서 일단 다른 table로 분리 
	
    private static final long serialVersionUID = 686774175556365789L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer soldierId; 
    
    private String userId;
    
    private String soldierPw; 
    
    private String soldierClass;

    private String soldierName;
    
    private String lastTime;   // 사용 시간    원래 log 파일로 받던지 해야되지만 일단 이걸로 
    
    private String soldierPhonenumber; 
    
    private String soldierImei; 
    
    private Integer vacation;
    
    private Integer groupPin;
    
    private int camera , enable , screen ; 
     // 사용할 수 있는 제한들 , 일단 10개로 설정. 
    
    public Soldier() {
    	this.userId = "empty"; 
    	this.soldierPw = "empty"; 
    	this.soldierClass = "empty"; 
    	this.soldierName = "empty"; 
    	this.soldierPhonenumber = "empty"; 
    	this.soldierImei = "empty";
    	this.lastTime  = "0";
    	this.groupPin = 0;
    	this.camera = 0 ;
    	this.enable = 0 ;
    	this.screen= 0;
    	this.vacation = 1;
    }

    public void setSoldierId(Integer soldierId) {
        this.soldierId = soldierId;
    }
    
    public Integer getSoldierId() {
        return soldierId; 
    }

    public void setSoldierPw(String soldierPw) {
        this.soldierPw = soldierPw;
    }
    
    public String getSoldierPw() {
        return soldierPw;
    }

   
    public void setSoldierName(String name)
    {
    	this.soldierName = name;
    }
    public String getSoldierName() {
    	return this.soldierName;
    }
    public void setSoldierClass(String c)
    {
    	this.soldierClass = c;
    }
    public String getSoldierClass() {
    	return this.soldierClass;
    }

	public String getSoldierPhonenumber() {
		return soldierPhonenumber;
	}

	public void setSoldierPhonenumber(String soldierPhonenumber) {
		this.soldierPhonenumber = soldierPhonenumber;
	}

	public String getSoldierImei() {
		return soldierImei;
	}

	public void setSoldierImei(String soldierImei) {
		this.soldierImei = soldierImei;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public Integer getVacation() {
		return vacation;
	}

	public void setVacation(Integer temp) {
		this.vacation = this.vacation * temp;
	}

	public Integer getGroupPin() {
		return groupPin;
	}

	public void setGroupPin(Integer groupPin) {
		this.groupPin = groupPin;
	}
	@Override
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

	public int getCamera() {
		return camera;
	}

	public void setCamera(int camera) {
		this.camera = camera;
	}

	public int getEnable() {
		return enable;
	}

	public void setEnable(int enable) {
		this.enable = enable;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	

	
   
}
