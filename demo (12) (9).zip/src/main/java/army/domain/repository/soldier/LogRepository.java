package army.domain.repository.soldier;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import army.domain.model.Log;


public interface LogRepository extends  JpaRepository<Log , Integer >{
	Log findByLogId (@Param("log_id") Integer logId);
}
